"""
config/asgi.py
ASGI config for TagsBikez project (for future async / websocket support).
"""

import os
from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

application = get_asgi_application()
